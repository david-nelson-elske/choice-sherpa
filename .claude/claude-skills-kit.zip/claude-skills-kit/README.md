# Claude Skills Kit

A complete set of Claude Code skills for **architecture design**, **feature definition**, and **TDD implementation**.

## Overview

This kit provides a seamless workflow from high-level project description to implemented, tested code:

```
Project Description → Architecture → Features → Implementation
        ↓                  ↓             ↓            ↓
/hexagonal-design    Module Specs   Feature Specs   TDD Code
```

## Quick Start

```bash
# 1. Extract
unzip claude-skills-kit.zip

# 2. Go to your project (or create new)
mkdir my-project && cd my-project
git init

# 3. Run setup
/path/to/claude-skills-kit/setup.sh

# 4. Start Claude Code
claude

# 5. Design your architecture
> /hexagonal-design "e-commerce platform with products, cart, and checkout"

# 6. Define a feature
> /feature-brief --module cart add-to-cart

# 7. Implement with TDD
> /dev features/cart/add-to-cart.md
```

## What's Included

### Skills (17 total)

#### Architecture & Definition (8 skills)

| Skill | Description |
|-------|-------------|
| `/hexagonal-design` | Design system architecture from project description |
| `/feature-brief` | Quick, architecture-aware feature capture |
| `/module-spec` | Full module specification generator |
| `/module-checklist` | Generate implementation tracking checklist |
| `/module-refine` | Validate and improve specifications |
| `/integration-spec` | Cross-module feature specifications |
| `/architecture-validate` | Validate specs against architecture |
| `SKILL-ARCHITECTURE.md` | Skill system documentation |

#### TDD & Execution (9 skills)

| Skill | Description |
|-------|-------------|
| `/dev` | Feature-driven orchestrator (file or folder) |
| `/tdd` | Single task TDD workflow |
| `/tdd-red` | RED phase - write failing test |
| `/tdd-green` | GREEN phase - minimal implementation |
| `/tdd-refactor` | REFACTOR phase - improve quality |
| `/test` | Run tests (auto-detects project type) |
| `/lint` | Run linters (auto-detects) |
| `/commit` | Create atomic commits |
| `/pr` | Create pull request |

### Templates (2 files)

| Template | Purpose |
|----------|---------|
| `ARCHITECTURE-TEMPLATE.md` | Skeleton for architecture documents |
| `HEXAGONAL-QUICK-REFERENCE.md` | One-page hexagonal architecture cheat sheet |

---

## Document Hierarchy

The skills produce documents in a layered hierarchy:

```
┌─────────────────────────────────────────────────────────────────────┐
│                    LEVEL 0: SYSTEM ARCHITECTURE                      │
│                docs/architecture/SYSTEM-ARCHITECTURE.md              │
│                                                                      │
│  Created by: /hexagonal-design                                       │
│  Contains: Modules, dependencies, shared types, phases               │
└─────────────────────────────────────────────────────────────────────┘
                                  │
                  ┌───────────────┼───────────────┐
                  ▼               ▼               ▼
┌─────────────────────┐ ┌─────────────────────┐ ┌─────────────────────┐
│   MODULE SPECS      │ │  SINGLE-MODULE      │ │  INTEGRATION SPECS  │
│ docs/modules/*.md   │ │  FEATURES           │ │ features/           │
│                     │ │ features/<m>/*.md   │ │  integrations/*.md  │
│ /module-spec        │ │ /feature-brief      │ │ /integration-spec   │
│ /module-refine      │ │                     │ │                     │
│ /module-checklist   │ │                     │ │                     │
└─────────────────────┘ └─────────────────────┘ └─────────────────────┘
          │                       │                       │
          └───────────────────────┴───────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────────────┐
│                         IMPLEMENTATION                               │
│                                                                      │
│  /dev, /tdd, /tdd-red, /tdd-green, /tdd-refactor                    │
│  /test, /lint, /commit, /pr                                         │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Complete Workflow

### Phase 1: Architecture Design

Start with a high-level project description:

```
> /hexagonal-design "community center platform with events, programs,
  facility bookings, memberships, donations, and volunteering"
```

This creates `docs/architecture/SYSTEM-ARCHITECTURE.md` containing:
- Module inventory with phases and dependencies
- Shared foundation types (Money, IDs, etc.)
- API structure
- Database schema overview
- Frontend/backend symmetry

### Phase 2: Feature Definition

#### Single-Module Features

For features that live in one module:

```
> /feature-brief --module events waitlist
```

Creates `features/events/waitlist.md`:
```markdown
# Feature: Event Waitlist

**Architecture:** docs/architecture/SYSTEM-ARCHITECTURE.md
**Module:** Events
**Phase:** 2
**Module Dependencies:** Foundation

> Allow users to join waitlist when events are full.

## Context
- Auto-promote when spot opens
- 24-hour confirmation window
- Max waitlist = 2x capacity

## Tasks
- [ ] Add WaitlistEntry entity
- [ ] Add JoinWaitlist method
- [ ] Create command handler
- [ ] Create HTTP endpoint

## Acceptance Criteria
- [ ] Can join waitlist when event full
- [ ] Cannot join if already registered
- [ ] Promotion is FIFO order
```

#### Cross-Module Features

For features spanning multiple modules:

```
> /integration-spec guest-checkout
```

Creates `features/integrations/guest-checkout.md` with:
- Modules involved and their roles
- Data flow diagrams
- Coordination points (sync/async)
- Failure modes and compensation
- Implementation phases

### Phase 3: Validation

Before implementing, validate against architecture:

```
> /architecture-validate features/events/waitlist.md
```

Output:
```
# Validation Report

✅ Module "Events" found in architecture
✅ Phase 2 matches architecture
✅ Dependencies are valid
⚠️ Missing "Files Affected" section
⚠️ Test count seems low for scope

Status: PASSED with warnings
```

### Phase 4: Elaboration (Optional)

For complex features, create full module specs:

```
> /module-spec features/events/waitlist.md
```

Creates `docs/modules/waitlist.md` with:
- Full business rules
- Database schema
- API endpoints
- Domain model
- Complete test inventory
- Exit criteria

Then generate tracking checklist:

```
> /module-checklist waitlist
```

Creates `REQUIREMENTS/CHECKLIST-waitlist.md` with trackable checkboxes.

### Phase 5: Implementation (TDD)

Execute the feature with TDD:

```
> /dev features/events/waitlist.md
```

This orchestrates:
1. For each task in the feature:
   - `/tdd-red` - Write failing test
   - `/tdd-green` - Minimal implementation
   - `/tdd-refactor` - Clean up
   - `/test` and `/lint` - Verify
   - `/commit` - Atomic commit
2. When complete:
   - `/pr` - Create pull request

---

## Workflow Diagrams

### New Project Setup

```
┌─────────────────────────────────────────────────────────────────┐
│  1. SETUP                                                        │
│     ./setup.sh /path/to/project                                  │
│                                                                  │
│  2. ARCHITECTURE                                                 │
│     /hexagonal-design "project description"                      │
│     → docs/architecture/SYSTEM-ARCHITECTURE.md                   │
│                                                                  │
│  3. VALIDATE BASELINE                                            │
│     /architecture-validate --all                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Feature Development

```
┌─────────────────────────────────────────────────────────────────┐
│  DEFINE                                                          │
│  /feature-brief --module events waitlist                         │
│  → features/events/waitlist.md                                   │
│                                                                  │
│  VALIDATE                                                        │
│  /architecture-validate features/events/waitlist.md              │
│                                                                  │
│  ELABORATE (if complex)                                          │
│  /module-spec features/events/waitlist.md                        │
│  /module-refine docs/modules/waitlist.md                         │
│  /module-checklist waitlist                                      │
│                                                                  │
│  IMPLEMENT                                                       │
│  /dev features/events/waitlist.md                                │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  For each task:                                          │    │
│  │    /tdd-red    → Write failing test                     │    │
│  │    /tdd-green  → Minimal implementation                 │    │
│  │    /tdd-refactor → Clean up                             │    │
│  │    /test && /lint                                       │    │
│  │    /commit                                              │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                  │
│  SHIP                                                            │
│  /pr                                                             │
└─────────────────────────────────────────────────────────────────┘
```

### Cross-Module Feature

```
┌─────────────────────────────────────────────────────────────────┐
│  DEFINE                                                          │
│  /integration-spec guest-checkout                                │
│  → features/integrations/guest-checkout.md                       │
│                                                                  │
│  VALIDATE                                                        │
│  /architecture-validate features/integrations/guest-checkout.md  │
│                                                                  │
│  IMPLEMENT (per module, in dependency order)                     │
│  /dev-module cart      (Phase 3)                                 │
│  /dev-module checkout  (Phase 4)                                 │
│  /dev-module payments  (Phase 4)                                 │
│                                                                  │
│  INTEGRATION TEST                                                │
│  /tdd-journey guest-checkout                                     │
└─────────────────────────────────────────────────────────────────┘
```

---

## Directory Structure After Setup

```
your-project/
├── .claude/
│   ├── commands/           # 17 skill files
│   │   ├── hexagonal-design.md
│   │   ├── feature-brief.md
│   │   ├── module-spec.md
│   │   ├── module-checklist.md
│   │   ├── module-refine.md
│   │   ├── integration-spec.md
│   │   ├── architecture-validate.md
│   │   ├── SKILL-ARCHITECTURE.md
│   │   ├── dev.md
│   │   ├── tdd.md
│   │   ├── tdd-red.md
│   │   ├── tdd-green.md
│   │   ├── tdd-refactor.md
│   │   ├── test.md
│   │   ├── lint.md
│   │   ├── commit.md
│   │   └── pr.md
│   └── templates/          # Reference templates
│       ├── ARCHITECTURE-TEMPLATE.md
│       └── HEXAGONAL-QUICK-REFERENCE.md
├── docs/
│   ├── architecture/       # System architecture
│   │   └── SYSTEM-ARCHITECTURE.md
│   └── modules/            # Module specifications
│       └── *.md
├── features/               # Feature specifications
│   ├── <module>/           # Per-module features
│   │   └── *.md
│   └── integrations/       # Cross-module features
│       └── *.md
├── REQUIREMENTS/           # Implementation checklists
│   └── CHECKLIST-*.md
├── CLAUDE.md               # Project configuration
└── ...
```

---

## Setup Options

```bash
# Basic setup
./setup.sh

# Setup to specific directory
./setup.sh /path/to/project

# Setup without example files
./setup.sh --skip-examples

# Show help
./setup.sh --help
```

---

## Configuration

Edit `CLAUDE.md` to configure:

```markdown
## Test Commands
test_all: npm test
test_coverage: npm test -- --coverage

## Lint Commands
lint: npm run lint
lint_fix: npm run lint -- --fix

## Dev Workflow Options
pr_per_feature: true
require_tests: true
require_lint: true
```

---

## Supported Languages

Auto-detection works for:

| Language | Test Tool | Lint Tool |
|----------|-----------|-----------|
| Go | `go test` | `golangci-lint` |
| TypeScript | `vitest` / `jest` | `eslint` |
| JavaScript | `vitest` / `jest` | `eslint` |
| Python | `pytest` | `ruff` / `flake8` |
| Rust | `cargo test` | `clippy` |

---

## Best Practices

### 1. Start with Architecture

Always run `/hexagonal-design` first. It establishes:
- Module boundaries
- Dependency rules
- Shared types
- Phase ordering

### 2. Validate Early

Run `/architecture-validate` before implementing:
- Catches dependency violations
- Identifies missing sections
- Suggests improvements

### 3. Use Feature Brief for Most Work

`/feature-brief` is faster than `/module-spec`:
- Use for typical features
- Upgrade to module-spec only when needed (10+ tasks, complex rules)

### 4. Integration Specs for Cross-Module

Use `/integration-spec` when:
- Feature touches 3+ modules
- Complex coordination needed
- Failure modes cross boundaries

### 5. Let TDD Guide Implementation

The `/dev` skill handles the full cycle:
- Don't skip red/green/refactor phases
- Each phase has its purpose
- Tests document behavior

---

## Requirements

- Claude Code CLI
- Git
- GitHub CLI (`gh`) for PR creation

---

## License

MIT - Use freely in your projects.

---

## Quick Reference Card

```
┌─────────────────────────────────────────────────────────────────┐
│  ARCHITECTURE          │  DEFINITION           │  EXECUTION     │
├─────────────────────────────────────────────────────────────────┤
│  /hexagonal-design     │  /feature-brief       │  /dev          │
│  /architecture-validate│  /module-spec         │  /tdd          │
│                        │  /module-refine       │  /tdd-red      │
│                        │  /module-checklist    │  /tdd-green    │
│                        │  /integration-spec    │  /tdd-refactor │
│                        │                       │  /test         │
│                        │                       │  /lint         │
│                        │                       │  /commit       │
│                        │                       │  /pr           │
└─────────────────────────────────────────────────────────────────┘

Workflow: Design → Define → Validate → Implement → Ship
```
