#!/bin/bash

# Claude Skills Kit - Complete Setup Script
# Full definition + execution workflow for hexagonal architecture projects

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

print_header() {
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${CYAN}${BOLD}  Claude Skills Kit - Architecture + TDD Workflow${NC}"
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
}

print_section() {
    echo -e "\n${BLUE}▸ $1${NC}"
}

# Parse arguments
TARGET_DIR=""
INIT_ARCH=false
PROJECT_DESC=""
SKIP_EXAMPLES=false

while [[ $# -gt 0 ]]; do
    case $1 in
        --init-architecture)
            INIT_ARCH=true
            shift
            ;;
        --project)
            PROJECT_DESC="$2"
            shift 2
            ;;
        --skip-examples)
            SKIP_EXAMPLES=true
            shift
            ;;
        --help|-h)
            echo "Usage: setup.sh [TARGET_DIR] [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --init-architecture    Run /hexagonal-design after setup"
            echo "  --project \"desc\"       Project description for architecture"
            echo "  --skip-examples        Don't copy example files"
            echo "  -h, --help             Show this help"
            echo ""
            echo "Examples:"
            echo "  ./setup.sh                              # Install to current directory"
            echo "  ./setup.sh /path/to/project             # Install to specific directory"
            echo "  ./setup.sh . --init-architecture        # Install and init architecture"
            echo "  ./setup.sh . --project \"e-commerce\"     # Install with project description"
            exit 0
            ;;
        *)
            TARGET_DIR="$1"
            shift
            ;;
    esac
done

# Default to current directory
if [ -z "$TARGET_DIR" ]; then
    TARGET_DIR="$(pwd)"
fi

print_header

echo -e "📁 Target directory: ${YELLOW}${TARGET_DIR}${NC}"
echo ""

# Check if target is a git repo
if [ ! -d "${TARGET_DIR}/.git" ]; then
    echo -e "${YELLOW}⚠️  Warning: Target is not a git repository${NC}"
    read -p "Initialize git repository? (Y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Nn]$ ]]; then
        echo -e "${YELLOW}Continuing without git...${NC}"
    else
        git init "${TARGET_DIR}"
        echo -e "${GREEN}✓${NC} Git repository initialized"
    fi
fi

# Create directory structure
print_section "Creating directory structure"

DIRS=(
    ".claude/commands"
    ".claude/templates"
    "features"
    "features/integrations"
    "docs/architecture"
    "docs/modules"
    "REQUIREMENTS"
)

for dir in "${DIRS[@]}"; do
    mkdir -p "${TARGET_DIR}/${dir}"
    echo -e "  ${GREEN}✓${NC} ${dir}/"
done

# Copy skill files
print_section "Installing skills (17 files)"

# Architecture & Definition Skills
ARCH_SKILLS=(
    "hexagonal-design.md"
    "feature-brief.md"
    "module-spec.md"
    "module-checklist.md"
    "module-refine.md"
    "integration-spec.md"
    "architecture-validate.md"
    "SKILL-ARCHITECTURE.md"
)

# TDD & Execution Skills
TDD_SKILLS=(
    "dev.md"
    "tdd.md"
    "tdd-red.md"
    "tdd-green.md"
    "tdd-refactor.md"
    "test.md"
    "lint.md"
    "commit.md"
    "pr.md"
)

echo -e "\n  ${BOLD}Architecture & Definition:${NC}"
for skill in "${ARCH_SKILLS[@]}"; do
    if [ -f "${SCRIPT_DIR}/.claude/commands/${skill}" ]; then
        cp "${SCRIPT_DIR}/.claude/commands/${skill}" "${TARGET_DIR}/.claude/commands/${skill}"
        echo -e "    ${GREEN}✓${NC} ${skill}"
    else
        echo -e "    ${RED}✗${NC} ${skill} (not found)"
    fi
done

echo -e "\n  ${BOLD}TDD & Execution:${NC}"
for skill in "${TDD_SKILLS[@]}"; do
    if [ -f "${SCRIPT_DIR}/.claude/commands/${skill}" ]; then
        cp "${SCRIPT_DIR}/.claude/commands/${skill}" "${TARGET_DIR}/.claude/commands/${skill}"
        echo -e "    ${GREEN}✓${NC} ${skill}"
    else
        echo -e "    ${RED}✗${NC} ${skill} (not found)"
    fi
done

# Copy templates
print_section "Installing templates (2 files)"

TEMPLATES=(
    "ARCHITECTURE-TEMPLATE.md"
    "HEXAGONAL-QUICK-REFERENCE.md"
)

for template in "${TEMPLATES[@]}"; do
    if [ -f "${SCRIPT_DIR}/.claude/templates/${template}" ]; then
        cp "${SCRIPT_DIR}/.claude/templates/${template}" "${TARGET_DIR}/.claude/templates/${template}"
        echo -e "  ${GREEN}✓${NC} ${template}"
    else
        echo -e "  ${RED}✗${NC} ${template} (not found)"
    fi
done

# Copy example files (unless skipped)
if [ "$SKIP_EXAMPLES" = false ]; then
    print_section "Installing examples"

    if [ -f "${SCRIPT_DIR}/features/example-user-auth.md" ]; then
        cp "${SCRIPT_DIR}/features/example-user-auth.md" "${TARGET_DIR}/features/"
        echo -e "  ${GREEN}✓${NC} features/example-user-auth.md"
    fi
fi

# Create CLAUDE.md if it doesn't exist
if [ ! -f "${TARGET_DIR}/CLAUDE.md" ]; then
    print_section "Creating CLAUDE.md"

    cat > "${TARGET_DIR}/CLAUDE.md" << 'CLAUDEMD'
# Project Development Guide

## Architecture

This project uses hexagonal architecture with TDD development workflow.

### Document Hierarchy

```
docs/architecture/SYSTEM-ARCHITECTURE.md    ← System design (Level 0)
     ↓
docs/modules/<module>.md                    ← Module specifications (Level 1)
     ↓
features/<module>/<feature>.md              ← Feature specifications (Level 2)
features/integrations/<integration>.md      ← Cross-module features
     ↓
REQUIREMENTS/CHECKLIST-<module>.md          ← Implementation tracking
```

## Available Skills

### Architecture & Definition

| Skill | Description |
|-------|-------------|
| `/hexagonal-design` | Design system architecture from project description |
| `/feature-brief` | Quick feature capture (architecture-aware) |
| `/module-spec` | Full module specification |
| `/module-checklist` | Generate implementation checklist |
| `/module-refine` | Validate and improve specifications |
| `/integration-spec` | Cross-module feature specification |
| `/architecture-validate` | Validate specs against architecture |

### TDD & Execution

| Skill | Description |
|-------|-------------|
| `/dev <path>` | Process feature file or folder |
| `/tdd <task>` | Single TDD cycle |
| `/tdd-red` | RED phase - write failing test |
| `/tdd-green` | GREEN phase - minimal implementation |
| `/tdd-refactor` | REFACTOR phase - improve quality |
| `/test` | Run tests |
| `/lint` | Run linters |
| `/commit` | Create git commit |
| `/pr` | Create pull request |

## Workflow

### 1. Design Architecture (Once)
```
/hexagonal-design "your project description"
```

### 2. Define Features
```
# Single-module feature
/feature-brief --module events waitlist

# Cross-module feature
/integration-spec guest-checkout

# Validate
/architecture-validate features/events/waitlist.md
```

### 3. Elaborate (If Needed)
```
# Complex features need full specs
/module-spec features/events/waitlist.md
/module-refine docs/modules/waitlist.md
/module-checklist waitlist
```

### 4. Implement (TDD)
```
# Execute feature with TDD
/dev features/events/waitlist.md

# Or process all features
/dev features/
```

## Commands

Customize these for your project:

```yaml
## Test Commands
test_all: npm test
test_coverage: npm test -- --coverage

## Lint Commands
lint: npm run lint
lint_fix: npm run lint -- --fix

## Build Commands
build: npm run build
```

## Dev Workflow Options

```yaml
pr_per_feature: true
require_tests: true
require_lint: true
```

## Quick Reference

- Architecture template: `.claude/templates/ARCHITECTURE-TEMPLATE.md`
- Hexagonal cheat sheet: `.claude/templates/HEXAGONAL-QUICK-REFERENCE.md`
- Skill documentation: `.claude/commands/SKILL-ARCHITECTURE.md`
CLAUDEMD

    echo -e "  ${GREEN}✓${NC} CLAUDE.md created"
else
    echo -e "\n📝 CLAUDE.md already exists, skipping..."
fi

# Create .gitignore additions
print_section "Updating .gitignore"

GITIGNORE_ADDITIONS="
# Claude Code local files
.claude/dev-progress.local.md
.claude/agents/
"

if [ -f "${TARGET_DIR}/.gitignore" ]; then
    if ! grep -q "Claude Code local files" "${TARGET_DIR}/.gitignore"; then
        echo "$GITIGNORE_ADDITIONS" >> "${TARGET_DIR}/.gitignore"
        echo -e "  ${GREEN}✓${NC} Added Claude Code entries to .gitignore"
    else
        echo -e "  ${YELLOW}○${NC} .gitignore already configured"
    fi
else
    echo "$GITIGNORE_ADDITIONS" > "${TARGET_DIR}/.gitignore"
    echo -e "  ${GREEN}✓${NC} Created .gitignore"
fi

# Print success message
echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}${BOLD}  ✅ Setup complete!${NC}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

echo -e "${BOLD}Installed:${NC}"
echo -e "  • ${BLUE}17 skills${NC} for architecture + TDD workflow"
echo -e "  • ${BLUE}2 templates${NC} for quick reference"
echo -e "  • ${BLUE}Directory structure${NC} for docs and features"
echo ""

echo -e "${BOLD}Directory Structure:${NC}"
echo -e "  ${TARGET_DIR}/"
echo -e "  ├── .claude/"
echo -e "  │   ├── commands/     ${CYAN}← 17 skill files${NC}"
echo -e "  │   └── templates/    ${CYAN}← Reference templates${NC}"
echo -e "  ├── docs/"
echo -e "  │   ├── architecture/ ${CYAN}← System architecture${NC}"
echo -e "  │   └── modules/      ${CYAN}← Module specifications${NC}"
echo -e "  ├── features/         ${CYAN}← Feature specifications${NC}"
echo -e "  │   └── integrations/ ${CYAN}← Cross-module features${NC}"
echo -e "  ├── REQUIREMENTS/     ${CYAN}← Implementation checklists${NC}"
echo -e "  └── CLAUDE.md         ${CYAN}← Project configuration${NC}"
echo ""

echo -e "${BOLD}Next Steps:${NC}"
echo ""
echo -e "  ${YELLOW}1. Design your architecture:${NC}"
echo -e "     ${BLUE}claude${NC}"
echo -e "     > /hexagonal-design \"your project description\""
echo ""
echo -e "  ${YELLOW}2. Define a feature:${NC}"
echo -e "     > /feature-brief --module <module> <feature-name>"
echo ""
echo -e "  ${YELLOW}3. Validate and implement:${NC}"
echo -e "     > /architecture-validate features/<module>/<feature>.md"
echo -e "     > /dev features/<module>/<feature>.md"
echo ""

echo -e "${BOLD}Quick Commands:${NC}"
echo ""
echo -e "  ${CYAN}/hexagonal-design${NC}      Design system architecture"
echo -e "  ${CYAN}/feature-brief${NC}         Quick feature capture"
echo -e "  ${CYAN}/integration-spec${NC}      Cross-module features"
echo -e "  ${CYAN}/architecture-validate${NC} Validate specifications"
echo -e "  ${CYAN}/dev${NC}                   TDD implementation"
echo ""

echo -e "Documentation: ${BLUE}.claude/commands/SKILL-ARCHITECTURE.md${NC}"
echo ""

# Optional: Initialize architecture
if [ "$INIT_ARCH" = true ]; then
    echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${YELLOW}  Architecture Initialization${NC}"
    echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""

    if [ -n "$PROJECT_DESC" ]; then
        echo -e "To initialize architecture, run Claude Code and execute:"
        echo ""
        echo -e "  ${BLUE}claude${NC}"
        echo -e "  > /hexagonal-design \"${PROJECT_DESC}\""
    else
        echo -e "To initialize architecture, run Claude Code and execute:"
        echo ""
        echo -e "  ${BLUE}claude${NC}"
        echo -e "  > /hexagonal-design \"describe your project here\""
    fi
    echo ""
fi
